from flask import Flask, jsonify, render_template, Response, request, send_file
import cv2
from PIL import Image
import io
import pytesseract
import base64
import numpy as np
import easyocr

app = Flask(__name__)

reader = easyocr.Reader(['en'], gpu=False)  # EasyOCR reader initialization

def generate_frames():
    camera = cv2.VideoCapture(0)  

    while True:
        success, frame = camera.read()
        if not success:
            break  
        else:
            ret, buffer = cv2.imencode('.jpg', frame)
            frame = buffer.tobytes()
            yield (b'--frame\r\n'
                   b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n')

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/video')
def video():
    return Response(generate_frames(), mimetype='multipart/x-mixed-replace; boundary=frame')

@app.route('/process_image', methods=['POST'])
def process_image():
    if 'image_data' in request.form:  
        image_data = request.form['image_data']
        image_data = image_data.split(',')[1]
        image_data = base64.b64decode(image_data)
        image = Image.open(io.BytesIO(image_data))

        # Get cropping data
        crop_x = int(request.form.get('x', 0))
        crop_y = int(request.form.get('y', 0))
        crop_width = int(request.form.get('width', image.width)) 
        crop_height = int(request.form.get('height', image.height))

        # Validate cropping coordinates
        if (crop_x < 0 or crop_y < 0 or crop_x + crop_width > image.width or crop_y + crop_height > image.height):
            return 'Invalid cropping coordinates', 400

        # Crop the image
        image = image.crop((crop_x, crop_y, crop_x + crop_width, crop_y + crop_height))

        # OCR using Pytesseract
        extracted_text = pytesseract.image_to_string(image)

        return extracted_text 

    else:
        return 'Image data not found', 400 

@app.route('/process_image2', methods=['POST'])
def process_image2():
    if 'image_data' in request.form:
        image_data = request.form['image_data']
        image_data = image_data.split(',')[1]
        image_data = base64.b64decode(image_data)
        image_np = np.frombuffer(image_data, np.uint8)
        image = cv2.imdecode(image_np, cv2.IMREAD_COLOR)

        # OCR with EasyOCR
        result = reader.readtext(image)

        Total = []
        for (bbox, text, prob) in result:
            Total.append(text)
            (tl, tr, br, bl) = bbox
            tl = (int(tl[0]), int(tl[1]))
            tr = (int(tr[0]), int(tr[1]))
            br = (int(br[0]), int(br[1]))
            bl = (int(bl[0]), int(bl[1]))
            cv2.rectangle(image, tl, br, (0, 255, 0), 1)  # Green bounding box
            cv2.putText(image, text, (tl[0], tl[1] - 2), cv2.FONT_HERSHEY_SIMPLEX, 0.4, (255, 0, 0),1)

        # Text extraction (You likely still want this)
        extracted_text = ' '.join(Total).split("SHIP TO", 1)[1] 

        # Encode modified image 
        _, img_encoded = cv2.imencode('.jpg', image) 
        img_str = base64.b64encode(img_encoded.tobytes()).decode('utf-8')

        return jsonify({
            'image': img_str,
            'text': extracted_text
        })

    else:
        return 'Image data not found', 400

if __name__ == "__main__":
    app.run(debug=True)
