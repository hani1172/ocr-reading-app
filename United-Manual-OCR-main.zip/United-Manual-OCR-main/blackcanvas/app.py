from flask import Flask, render_template, request, redirect, url_for
from werkzeug.utils import secure_filename
import cv2
import pytesseract
import numpy as np
import os
import base64

app = Flask(__name__)

pytesseract.pytesseract.tesseract_cmd = r'C:\Program Files\Tesseract-OCR\tesseract.exe'

def process_image(file):
    # Check if the file is empty
    if file and file.filename == '':
        return None, "Error: Empty file uploaded", None

    # Read image from file
    image = cv2.imdecode(np.frombuffer(file.read(), np.uint8), cv2.IMREAD_COLOR)
    if image is None:
        return None, "Error: Unable to decode image", None

    img_RGB = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    results = pytesseract.image_to_data(img_RGB, output_type=pytesseract.Output.DICT)

    canvas = np.zeros_like(image)

    extracted_text = ""
    for i in range(len(results['text'])):
        x, y, w, h = results['left'][i], results['top'][i], results['width'][i], results['height'][i]
        text = results['text'][i]

        if text != "":
            text_region = image[y:y+h, x:x+w]
            canvas[y:y+h, x:x+w] = text_region

            cv2.rectangle(canvas, (x, y), (x + w, y + h), (255, 255, 255), 2)
            cv2.putText(canvas, text, (x, y - 5), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 2)

            extracted_text += text + "\n"

    # Encode image to base64 string
    _, buffer = cv2.imencode('.png', canvas)
    encoded_image = base64.b64encode(buffer)
    encoded_image_string = encoded_image.decode('utf-8')

    return encoded_image_string, None, extracted_text

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/upload', methods=['POST'])
def upload_file():
    if 'file' not in request.files:
        return redirect(request.url)
    
    file = request.files['file']
    
    if file.filename == '':
        return redirect(request.url)
    
    result, error_message, extracted_text = process_image(file)
    if result is not None:
        return render_template('result.html', result=result, extracted_text=extracted_text)
    else:
        return render_template('result.html', error_message=error_message)

if __name__ == '__main__':
    app.run(debug=True)
 